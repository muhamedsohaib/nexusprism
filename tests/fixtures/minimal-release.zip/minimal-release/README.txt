fixture content for extract test
